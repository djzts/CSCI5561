function [y] = ReLu(x)
y = x;
y(x <= 0) = 0;
end